package dev.fullstackcode.eis;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringbootValidationExampleApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringbootValidationExampleApplication.class, args);
	}

}
