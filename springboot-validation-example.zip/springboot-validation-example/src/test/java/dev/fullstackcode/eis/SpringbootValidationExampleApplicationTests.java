package dev.fullstackcode.eis;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringbootValidationExampleApplicationTests {

	@Test
	void contextLoads() {
	}

}
